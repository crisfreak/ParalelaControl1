#include <iostream>
#define MAX 100000
using namespace std;

int ASCII(char L)
{
    if (L>47 && L<58)
        return (L-48);
    else
        return (-1);
}
int potencia(int base, int exponente)
{
    int auxiliar = 1;
    while(exponente > 0)
    {
        auxiliar  = base*auxiliar;
        exponente = exponente - 1;
    }
    return auxiliar;
}
float evaluar(int funcion[MAX],float valor, int n)
{
    int indice = 0;
    float sumatoria = 0;
    for(indice = 0; indice < n; indice++)
    {
        if((indice%2) == 0)
        {
           sumatoria= sumatoria + (potencia(valor,funcion[indice+1]))*funcion[indice];
        }
    }
    return sumatoria;
}
float derivar(int funcion[MAX],float valor, int n)
{
    int indice = 0;
    float sumatoria = 0, multiplicando = 0, exponente = 0;


    for(indice = 0; indice < n; indice++)
    {
        if((indice%2) == 0)
        {
           multiplicando = funcion[indice]*funcion[indice + 1];
           exponente = funcion[indice + 1] - 1;
            sumatoria = sumatoria + (potencia(valor,exponente))*multiplicando;
        }
    }
    return sumatoria;
}

float Evaluacion_Newton(int funcion[MAX], int n)
{
    float indice = 0;
    while(evaluar(funcion, indice, n) <= 0)
    {
        indice = indice +1;
    }
    return indice;
}

float Ecuacion(float valor, int funcion[MAX], int n)
{
    float resultado = 0;
    resultado = valor + (evaluar(funcion, valor, n))/(derivar(funcion, valor, n));
    return resultado;
}

float Desarrollo_Ejercicio(int funcion[MAX], int n)
{
    float valor_inicial = 0, valor_prueba = 0;
    valor_inicial = Evaluacion_Newton(funcion, n);
    valor_prueba = Ecuacion(valor_inicial,funcion,n);
    float margen_error = 0.00001;
    while(valor_prueba-valor_inicial>margen_error)
    {
        valor_inicial=valor_prueba;
        valor_prueba = Ecuacion(valor_inicial,funcion,n);
    }
    return valor_prueba;
}

int main(int argc, char *argv[])
{
    // Creo arreglo
    int Arreglo[99];
    // Empiezo a trabajar
    // NO SE HARA NINGUNA COMPROBACION, SE ASUME QUE EL USUARIO INGRESARA CORRECTAMENTE EL PARAMETRO
    int iEc=0;
    int jArr=0;
    while (argv[1][iEc]=='-' || argv[1][iEc]=='+' || ASCII(argv[1][iEc])!=-1)
    {
        // �Es negativa la cte?
        int Neg=1;
        if (argv[1][iEc]=='-')
        {
            Neg=-1;
            iEc++;
        }
        if (argv[1][iEc]=='+')
        {
            iEc++;
        }
        // Trabajo con la cte
        Arreglo[jArr]=ASCII(argv[1][iEc])*Neg;
        while (ASCII(argv[1][iEc+1])>-1 && ASCII(argv[1][iEc+1])<10)
        {
            Arreglo[jArr]=Arreglo[jArr]*10+ASCII(argv[1][iEc+1]);
            iEc++;
        }
        // Salto valores tipicos, es decir, el "x**" y paso a almacenar la siguiente variable.
        iEc=iEc+4;
        jArr++;
        // �Es negativa la 2nda cte?
        Neg=1;
        if (argv[1][iEc]=='-')
        {
            Neg=-1;
            iEc++;
        }
        Arreglo[jArr]=ASCII(argv[1][iEc])*Neg;
        while (ASCII(argv[1][iEc+1])>-1 && ASCII(argv[1][iEc+1])<10)
        {
            Arreglo[jArr]=Arreglo[jArr]*10+ASCII(argv[1][iEc+1]);
            iEc++;
        }
        iEc++;
        jArr++;
    }
    cout << Desarrollo_Ejercicio(Arreglo,jArr);
    return 0;
}

